#include <stdlib.h>
#include <stdio.h>
#include "addition.h"
int somme(int a, int b)
{
	return a + b;
}